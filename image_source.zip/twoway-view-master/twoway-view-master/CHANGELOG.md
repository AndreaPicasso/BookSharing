Change Log
==========

Version 0.1.2
-------------

 * Add smoothScrollBy() and smoothScrollToPosition() support
 * Misc bug fixes

Version 0.1.1
-------------

 * Misc bug fixes

Version 0.1.0
-------------

Initial release.
